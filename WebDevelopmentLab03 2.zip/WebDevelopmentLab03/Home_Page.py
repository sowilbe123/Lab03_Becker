import streamlit as st
st.title("Web Development Lab03")
# Assignment Data 
# TODO: Fill out your team number, section, and team members

st.header("CS 1301")
st.subheader("Team 31, Web Development - Section A")
st.subheader("Sonya Becker, Andres Saa")

#st.image("PUT IMAGE HERE")
#Introduction

st.write("""
Welcome to our Streamlit Web Development Lab03 app! You can navigate between the pages using the sidebar to the left. The following pages are:

1. **CoinScope**: A live cryptocurrency dashboard. Search and compare coins, explore price trends over time, and analyze market cap and volume data through interactive charts.
2. **CryptoBot**: An AI-powered cryptocurrency chatbot. Ask anything about crypto, ranging from how the blockchain works, to coin histories, to generating investing concepts.

""")

